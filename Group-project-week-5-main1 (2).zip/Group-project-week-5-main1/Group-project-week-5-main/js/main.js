/* Our Working Process : boxes */
const elements = document.querySelectorAll(".plus_icon");
elements.forEach((element) => {
  element.addEventListener("click", function() {
    // i got help and findout it is better to use generalized function by using this
    const box = this.closest(".box_section9");
    console.log(box)
    if (box.classList.contains("new_back")) {
      box.classList.remove("new_back");
      const existingPart = box.querySelector("span");
      if (existingPart) {
        box.removeChild(existingPart);
      }
    } else {
      box.classList.add("new_back");
      const new_part = document.createElement("span");
      new_part.innerHTML = `
        <hr>
        <p>During the initial consultation, we will discuss your business goals and objectives, target audience, and current marketing <br />efforts. This will allow us to understand your needs and tailor our services to best fit your requirements.</p>`;
      box.appendChild(new_part);
    }
  });
});



















